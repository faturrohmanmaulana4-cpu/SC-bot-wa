const { WA_DEFAULT_EPHEMERAL } = require('@whiskeysockets/baileys');
const fs = require('fs');
const path = require('path');

// Path untuk database welcome
const DB_PATH = path.join(__dirname, '../db-welcome.json');

// Fungsi untuk memuat database
function loadDB() {
    if (!fs.existsSync(DB_PATH)) {
        const defaultDB = {};
        fs.writeFileSync(DB_PATH, JSON.stringify(defaultDB, null, 2));
        return defaultDB;
    }
    return JSON.parse(fs.readFileSync(DB_PATH, 'utf-8'));
}

async function GroupParticipants(sock, { id, participants, action, author }) {
    try {
        const gcdata = await sock.groupMetadata(id);
        const subject = gcdata.subject;
        const db = loadDB();
        const groupSettings = db[id];

        console.log('🔍 DEBUG WELCOME:', {
            groupId: id,
            groupName: subject,
            action: action,
            participants: participants,
            groupSettings: groupSettings
        });

        // Jika tidak ada settings untuk grup ini, buat default
        if (!groupSettings) {
            console.log('⚠️ Tidak ada settings untuk grup ini, menggunakan default...');
            db[id] = {
                welcome: { enabled: true },
                goodbye: { enabled: true }
            };
            // Tidak perlu save di sini, biar plugin yang handle
            return;
        }

        for (const jid of participants) {
            let check = author && author !== jid && author.length > 1;
            let tag = check ? [author, jid] : [jid];

            // Dapatkan nama pengguna
            let userName = 'Pengguna';
            try {
                const contact = await sock.fetchStatus(jid).catch(() => null);
                if (contact && contact.status) {
                    userName = contact.status;
                } else {
                    const contactObj = sock.contacts?.[jid];
                    if (contactObj && contactObj.name) {
                        userName = contactObj.name;
                    } else {
                        userName = `@${jid.split('@')[0]}`;
                    }
                }
            } catch (error) {
                userName = `@${jid.split('@')[0]}`;
            }

            // Nama admin yang melakukan aksi
            let adminName = 'System';
            if (author) {
                try {
                    const adminContact = await sock.fetchStatus(author).catch(() => null);
                    adminName = adminContact?.status || `@${author.split('@')[0]}`;
                } catch (error) {
                    adminName = `@${author.split('@')[0]}`;
                }
            }

            switch (action) {
                case "add":
                    // Cek apakah welcome diaktifkan
                    if (!groupSettings.welcome || groupSettings.welcome.enabled === false) {
                        console.log('⚠️ Welcome message dinonaktifkan untuk grup:', subject);
                        return;
                    }

                    console.log('🎉 Mengirim welcome message...');

                    const welcomeText = groupSettings.welcome?.text || 
                        '🎉 Selamat datang @user di @group!\n\nSemoga betah ya! 😊';
                    const welcomeImage = groupSettings.welcome?.image || 
                        "https://raw.githubusercontent.com/zionjs0/whatsapp-media/main/file_1762684126003.jpg";

                    const processedWelcome = processWelcomeText(welcomeText, {
                        user: userName,
                        userJid: jid,
                        group: subject,
                        desc: gcdata.desc || "Tidak ada deskripsi",
                        size: gcdata.participants?.length || 0,
                        author: adminName
                    });

                    await sock.sendMessage(id, {
                        text: processedWelcome.text,
                        contextInfo: {
                            mentionedJid: processedWelcome.mentions,
                            isForwarded: false,
                            forwardedNewsletterMessageInfo: {
                                newsletterJid: null,
                                newsletterName: ``,
                                serverId: 200
                            },
                            externalAdReply: {
                                title: `Welcome • ${subject}`,
                                thumbnailUrl: welcomeImage,
                                renderLargerThumbnail: true,
                                mediaType: 1,
                                previewType: 1,
                                sourceUrl: "https://Fyzz-MD"
                            }
                        }
                    }, {
                        ephemeralExpiration: WA_DEFAULT_EPHEMERAL,
                        quoted: null
                    });
                    break;

                case "remove":
                    // Cek apakah goodbye diaktifkan
                    if (!groupSettings.goodbye || groupSettings.goodbye.enabled === false) {
                        console.log('⚠️ Goodbye message dinonaktifkan untuk grup:', subject);
                        return;
                    }

                    console.log('👋 Mengirim goodbye message...');

                    const goodbyeText = groupSettings.goodbye?.text || 
                        '👋 Selamat tinggal @user!\n\nSemoga sukses selalu! 💫';
                    const goodbyeImage = groupSettings.goodbye?.image || 
                        "https://raw.githubusercontent.com/zionjs0/whatsapp-media/main/file_1762684105325.jpg";

                    const processedGoodbye = processWelcomeText(goodbyeText, {
                        user: userName,
                        userJid: jid,
                        group: subject,
                        desc: gcdata.desc || "Tidak ada deskripsi",
                        size: gcdata.participants?.length || 0,
                        author: adminName
                    });

                    await sock.sendMessage(id, {
                        text: processedGoodbye.text,
                        contextInfo: {
                            mentionedJid: processedGoodbye.mentions,
                            isForwarded: false,
                            forwardedNewsletterMessageInfo: {
                                newsletterJid: null,
                                newsletterName: ``,
                                serverId: 200
                            },
                            externalAdReply: {
                                title: `Goodbye • ${subject}`,
                                thumbnailUrl: goodbyeImage,
                                renderLargerThumbnail: true,
                                mediaType: 1,
                                previewType: 1,
                                sourceUrl: "https://Fyzz-MD"
                            }
                        }
                    }, {
                        ephemeralExpiration: WA_DEFAULT_EPHEMERAL,
                        quoted: null
                    });
                    break;

                case "promote":
                    if (author) {
                        await sock.sendMessage(
                            id,
                            {
                                text: `🎉 *@${author.split("@")[0]} telah menjadikan @${jid.split("@")[0]} sebagai admin grup ini!* 👑`,
                                contextInfo: { mentionedJid: [...tag] }
                            },
                            { ephemeralExpiration: WA_DEFAULT_EPHEMERAL }
                        );
                    }
                    break;

                case "demote":
                    if (author) {
                        await sock.sendMessage(
                            id,
                            {
                                text: `😔 *@${author.split("@")[0]} telah menghapus @${jid.split("@")[0]} dari jabatan admin grup ini.* 🚫`,
                                contextInfo: { mentionedJid: [...tag] }
                            },
                            { ephemeralExpiration: WA_DEFAULT_EPHEMERAL }
                        );
                    }
                    break;

                default:
                    console.log(`⚠️ Aksi tidak dikenal: ${action} untuk ${jid} di grup ${subject}`);
            }
        }
    } catch (err) {
        console.error('Error dalam GroupParticipants:', err);
    }
}

// Fungsi untuk memproses teks welcome/goodbye
function processWelcomeText(text, data) {
    let processedText = text;
    const mentions = [];

    // Handle mention @user
    if (processedText.includes('@user')) {
        mentions.push(data.userJid);
        processedText = processedText.replace(/@user/g, `@${data.userJid.split('@')[0]}`);
    }

    // Ganti variabel lainnya
    processedText = processedText
        .replace(/@group/g, data.group)
        .replace(/@desc/g, data.desc)
        .replace(/@member/g, data.size)
        .replace(/@admin/g, data.author);

    return {
        text: processedText,
        mentions: mentions
    };
}

module.exports = GroupParticipants;