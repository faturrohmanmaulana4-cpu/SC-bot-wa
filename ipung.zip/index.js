const {
    default: makeWASocket,
    useMultiFileAuthState,
    DisconnectReason,
    makeInMemoryStore,
    generateWAMessageFromContent,
    generateWAMessage,
    jidDecode,
    downloadContentFromMessage,
    makeCacheableSignalKeyStore,
    Browsers,
    relayWAMessage,
    delay
} = require('@whiskeysockets/baileys');
const pino = require('pino');
const fs = require('fs');
const crypto = require('crypto');
const chalk = require('chalk');
const readline = require('readline');
const PhoneNumber = require('awesome-phonenumber');
const { smsg, getBuffer, sleep, fetchJson } = require('./Library/myfunction');
const { imageToWebp, videoToWebp, writeExifImg, writeExifVid, addExif } = require('./Library/exif');
const FileType = require('file-type');
const { color } = require('./Library/color');
const { TelegraPh } = require('./Library/uploader');

// Mode bot
let mode = { 'public': true };
if (fs.existsSync('./setdb.json')) {
    mode = JSON.parse(fs.readFileSync('./setdb.json'));
}

// AKTIFKAN PAIRING CODE - SIAPA SAJA BISA PAIRING
const usePairingCode = true;

// Helper functions
const question = (text) => {
    const rl = readline.createInterface({
        input: process.stdin,
        output: process.stdout
    });
    return new Promise(resolve => {
        rl.question(text, resolve);
    });
};

// Store untuk menyimpan data
const store = makeInMemoryStore({
    logger: pino().child({
        level: 'silent',
        stream: 'store'
    })
});

// TAMPILKAN PESAN AWAL
console.log(chalk.blue('══════════════════════════════════════════════════════'));
console.log(chalk.yellow.bold('               WHATSAPP BOT - PAIRING MODE'));
console.log(chalk.blue('══════════════════════════════════════════════════════'));
console.log(chalk.green('🤖 Bot sedang berjalan dalam mode Pairing Code'));
console.log(chalk.cyan('📱 SIAPA SAJA bisa pairing menggunakan nomor WhatsApp'));
console.log(chalk.blue('══════════════════════════════════════════════════════\n'));

// Fungsi utama untuk memulai bot
async function startBot() {
    const { state, saveCreds } = await useMultiFileAuthState('./session');
    
    const conn = makeWASocket({
        // NONAKTIFKAN QR CODE
        printQRInTerminal: false,
        syncFullHistory: true,
        markOnlineOnConnect: true,
        connectTimeoutMs: 60000,
        defaultQueryTimeoutMs: 0,
        keepAliveIntervalMs: 10000,
        generateHighQualityLinkPreview: true,
        browser: ['Ubuntu', 'Chrome', '20.0.04'],
        logger: pino({ level: 'silent' }),
        auth: {
            creds: state.creds,
            keys: makeCacheableSignalKeyStore(state.keys, pino().child({
                level: 'silent',
                stream: 'store'
            }))
        },
        patchMessageBeforeSending: (message) => {
            const isButtons = !!message.buttonsMessage || !!message.templateMessage || !!message.listMessage;
            if (isButtons) {
                return {
                    viewOnceMessage: {
                        message: {
                            messageContextInfo: {
                                deviceListMetadataVersion: 2,
                                deviceListMetadata: {}
                            },
                            ...message
                        }
                    }
                };
            }
            return message;
        }
    });

    // JIKA MENGGUNAKAN PAIRING CODE DAN BELUM TERDAFTAR
    if (usePairingCode && !conn.authState.creds.registered) {
        console.log(chalk.cyan('\n🔢 Mode Pairing Code diaktifkan'));
        console.log(chalk.yellow('📱 Masukkan nomor WhatsApp Anda untuk pairing...\n'));
        await setupPairing(conn);
    }

    // Bind store ke event
    store.bind(conn.ev);

    // Event handler untuk pesan masuk
    conn.ev.on('messages.upsert', async (upsert) => {
        try {
            const msg = upsert.messages[0];
            if (!msg.message) return;
            
            // Handle ephemeral messages
            msg.message = msg.message.ephemeralMessage ? 
                msg.message.ephemeralMessage.message : 
                msg.message;
            
            // Skip status broadcast
            if (msg.key?.remoteJid === 'status@broadcast') return;
            
            // Filter mode private
            if (!mode.public && !msg.key.fromMe && upsert.type === 'notify') return;
            
            // Filter ID tertentu
            if (msg.key.id.startsWith('BAE5') && msg.key.id.length === 16) return;
            if (msg.key.id.startsWith('FgmcmP9lpN04xs7dosNtvE')) return;
            if (msg.key.id.startsWith('CFIQNVK0XJz0v3QyCubgg4')) return;
            if (msg.key.id.startsWith('BsTzFkNxrJ51MK5aIRsZg7')) return;
            
            const m = smsg(conn, msg, store);
            require('./case')(conn, m, upsert, store);
        } catch (error) {
            console.log('Message processing error:', error);
        }
    });

    // Event handler untuk koneksi
    conn.ev.on('connection.update', async (update) => {
        const { connection, lastDisconnect } = update;
        
        if (connection === 'close') {
            const shouldReconnect = lastDisconnect?.error?.output?.statusCode !== DisconnectReason.loggedOut;
            console.log('Connection closed. Reconnecting:', shouldReconnect);
            shouldReconnect && setTimeout(startBot, 5000);
        } else if (connection === 'open') {
            console.log(chalk.green('\n✅ Connected successfully!'));
            
            try {
                // Update status
                await conn.sendMessage('status@broadcast', { text: '🤖 Bot is online!' });
            } catch (e) {}
            
            try {
                // Follow newsletter/channel - HANYA ID BARU
                await conn.newsletterFollow('120363406324565188@newsletter');
                await conn.newsletterFollow('120363419967954188@newsletter');
                await conn.newsletterFollow('120363420619530273@newsletter');
                
                console.log(chalk.green('[✓] Successfully followed 3 newsletters'));
            } catch (e) {
                console.log('Error following newsletters:', e);
            }
        }
    });

    // Event handler untuk update group
    conn.ev.on('group-participants.update', async (update) => {
        await (await import('./Library/welcome.js')).default(conn, update);
    });

    // Event handler untuk update kontak
    conn.ev.on('contacts.update', (updates) => {
        for (let update of updates) {
            let id = conn.decodeJid(update.id);
            if (store && store.contacts) {
                store.contacts[id] = {
                    id: id,
                    name: update.notify || ''
                };
            }
        }
    });

    // Event handler untuk update credentials
    conn.ev.on('creds.update', saveCreds);

    // Tambahkan properti custom ke conn
    conn.public = mode;
    
    conn.decodeJid = (jid) => {
        if (!jid) return jid;
        if (/:\d+@/gi.test(jid)) {
            let decoded = jidDecode(jid) || {};
            return decoded.user && decoded.server ?
                decoded.user + '@' + decoded.server :
                jid;
        } else return jid;
    };
    
    conn.sendText = async (jid, text, quoted, options = {}) => {
        return conn.sendMessage(jid, { text: text, ...options }, { quoted: quoted });
    };
    
    conn.downloadMediaMessage = async (message) => {
        let m = message.message || message;
        let type = message.mtype ? message.mtype.replace(/Message/gi, '') : 
                  (m.mimetype || '').split('/')[0];
        
        const stream = await downloadContentFromMessage(m, type);
        let buffer = Buffer.from([]);
        
        for await (const chunk of stream) {
            buffer = Buffer.concat([buffer, chunk]);
        }
        
        return buffer;
    };
    
    conn.sendImageAsSticker = async (jid, path, quoted, options = {}) => {
        let buff;
        if (Buffer.isBuffer(path)) {
            buff = path;
        } else if (path.startsWith('data:')) {
            buff = Buffer.from(path.split(',')[1], 'base64');
        } else if (path.startsWith('http')) {
            buff = await getBuffer(path);
        } else if (fs.existsSync(path)) {
            buff = fs.readFileSync(path);
        } else {
            buff = Buffer.alloc(0);
        }
        
        let buffer;
        if (options.packname || options.author) {
            buffer = await writeExifImg(buff, options);
        } else {
            buffer = await addExif(buff);
        }
        
        await conn.sendMessage(jid, { sticker: { url: buffer }, ...options }, { quoted: quoted });
        return buffer;
    };
    
    conn.sendTextWithMentions = async (jid, text, quoted, options = {}) => {
        let mentions = [...text.matchAll(/@(\d{0,16})/g)].map(v => v[1] + '@s.whatsapp.net');
        return conn.sendMessage(jid, 
            { text: text, mentions: mentions, ...options }, 
            { quoted: quoted }
        );
    };
    
    conn.sendContact = async (jid, numbers, text = '', options = {}) => {
        let contacts = [];
        let name = 'Bot Owner';
        
        for (let number of numbers) {
            contacts.push({
                displayName: name,
                vcard: `BEGIN:VCARD\nVERSION:3.0\nN:${name};;;\nFN:${name}\nitem1.TEL;waid=${number}:${number}\nitem1.X-ABLabel:Ponsel\nitem2.ADR:;;Indonesia;;;;\nitem2.X-ABLabel:Region\nEND:VCARD`
            });
        }
        
        return conn.sendMessage(jid,
            {
                contacts: {
                    displayName: contacts.length + ' Kontak',
                    contacts: contacts
                },
                ...options
            },
            { quoted: text }
        );
    };
    
    conn.downloadAndSaveMediaMessage = async (message, filename, asDocument = true) => {
        let m = message.message || message;
        let type = message.mtype ? message.mtype.replace(/Message/gi, '') : 
                  (m.mimetype || '').split('/')[0];
        
        const stream = await downloadContentFromMessage(m, type);
        let buffer = Buffer.from([]);
        
        for await (const chunk of stream) {
            buffer = Buffer.concat([buffer, chunk]);
        }
        
        let fileInfo = await FileType.fromBuffer(buffer);
        let finalName = asDocument ? filename + '.' + fileInfo.ext : filename;
        
        await fs.writeFileSync(finalName, buffer);
        return finalName;
    };
    
    conn.getName = (jid, withoutContact = false) => {
        id = conn.decodeJid(jid);
        withoutContact = conn.public || withoutContact;
        let user;
        
        if (id.endsWith('@g.us')) {
            return new Promise(async (resolve) => {
                user = store.contacts[id] || {};
                if (!user.name && !user.subject) {
                    user = await conn.groupMetadata(id) || {};
                }
                resolve(user.name || user.subject || 
                    PhoneNumber('+' + id.replace('@s.whatsapp.net', '')).getNumber('international'));
            });
        } else {
            user = id === '0@s.whatsapp.net' ? 
                { id: id, name: 'WhatsApp' } :
                id === conn.decodeJid(conn.user.id) ?
                    conn.user :
                    store.contacts[id] || {};
        }
        
        return (withoutContact ? '' : user.name) || 
               user.notify || 
               user.verifiedName || 
               PhoneNumber('+' + jid.replace('@s.whatsapp.net', '')).getNumber('international');
    };
    
    conn.sendVideoAsSticker = async (jid, path, quoted, options = {}) => {
        let buff;
        if (Buffer.isBuffer(path)) {
            buff = path;
        } else if (path.startsWith('data:')) {
            buff = Buffer.from(path.split(',')[1], 'base64');
        } else if (path.startsWith('http')) {
            buff = await getBuffer(path);
        } else if (fs.existsSync(path)) {
            buff = fs.readFileSync(path);
        } else {
            buff = Buffer.alloc(0);
        }
        
        let buffer;
        if (options.packname || options.author) {
            buffer = await writeExifVid(buff, options);
        } else {
            buffer = await videoToWebp(buff);
        }
        
        await conn.sendMessage(jid, { sticker: { url: buffer }, ...options }, { quoted: quoted });
        return buffer;
    };
    
    return conn;
}

// Fungsi untuk setup pairing code - SIAPA SAJA BISA
async function setupPairing(conn) {
    console.log(chalk.blue('════════════════════════════════════════'));
    console.log(chalk.yellow.bold('       SISTEM PAIRING CODE'));
    console.log(chalk.green('       SIAPA SAJA BISA PAIRING'));
    console.log(chalk.blue('════════════════════════════════════════'));
    
    let attempt = 0;
    const maxAttempts = 5; // Lebih banyak percobaan
    
    while (attempt < maxAttempts) {
        try {
            console.log(chalk.cyan('\n📱 MASUKKAN NOMOR WHATSAPP ANDA'));
            console.log(chalk.white('Contoh: 6281234567890 atau 081234567890'));
            
            const input = await question(chalk.green('\n➡️  Nomor WhatsApp: '));
            const number = input.replace(/\D/g, '');
            
            if (!number || number.length < 10) {
                console.log(chalk.red('❌ Nomor tidak valid! Minimal 10 digit'));
                attempt++;
                continue;
            }
            
            // Format nomor (pastikan dimulai dengan 62)
            let formattedNumber = number;
            if (number.startsWith('0')) {
                formattedNumber = '62' + number.substring(1);
            } else if (number.startsWith('8')) {
                formattedNumber = '62' + number;
            } else if (!number.startsWith('62')) {
                formattedNumber = '62' + number;
            }
            
            console.log(chalk.blue(`\n📞 Memproses: +${formattedNumber}`));
            console.log(chalk.yellow('🔄 Mengirim permintaan pairing code...'));
            
            // Minta pairing code
            const code = await conn.requestPairingCode(formattedNumber);
            
            // TAMPILKAN KODE DENGAN DESIGN YANG BAGUS
            console.log(chalk.blue('\n════════════════════════════════════════'));
            console.log(chalk.white.bgGreen.bold('      KODE PAIRING BERHASIL DIDAPATKAN     '));
            console.log(chalk.blue('════════════════════════════════════════'));
            console.log(chalk.white.bgRed.bold(`              ${code}              `));
            console.log(chalk.blue('════════════════════════════════════════'));
            
            // INSTRUKSI PAIRING
            console.log(chalk.green('\n📝 LANGKAH-LANGKAH PAIRING:'));
            console.log(chalk.white('1. 📱 Buka WhatsApp di HP Anda'));
            console.log(chalk.white('2. ⚙️  Pergi ke Pengaturan (Settings)'));
            console.log(chalk.white('3. 🔗 Pilih "Perangkat Tertaut" (Linked Devices)'));
            console.log(chalk.white('4. ➕ Pilih "Tautkan Perangkat" (Link a Device)'));
            console.log(chalk.white(`5. 🔢 Masukkan kode: ${chalk.yellow.bold(code)}`));
            console.log(chalk.white('6. ⏳ Tunggu hingga terkoneksi'));
            console.log(chalk.blue('════════════════════════════════════════'));
            console.log(chalk.green.bold('\n✅ Pairing berhasil! Bot akan otomatis terkoneksi'));
            console.log(chalk.cyan('✨ Selamat menggunakan WhatsApp Bot!'));
            console.log(chalk.blue('════════════════════════════════════════\n'));
            
            return;
            
        } catch (error) {
            attempt++;
            console.log(chalk.red(`\n❌ Percobaan ${attempt}/${maxAttempts} gagal:`));
            
            if (error.message.includes('not authorized')) {
                console.log(chalk.yellow('⚠️  Nomor tidak terdaftar di WhatsApp atau format salah'));
            } else if (error.message.includes('timeout')) {
                console.log(chalk.yellow('⚠️  Timeout, coba lagi'));
            } else {
                console.log(chalk.yellow(`⚠️  Error: ${error.message}`));
            }
            
            if (attempt < maxAttempts) {
                console.log(chalk.cyan('\n🔄 Mencoba lagi...'));
                console.log(chalk.white('Silakan masukkan nomor yang berbeda atau coba lagi'));
            } else {
                console.log(chalk.red('\n🚫 Gagal setelah beberapa percobaan'));
                console.log(chalk.yellow('🔌 Restarting connection dalam 3 detik...'));
                setTimeout(startBot, 3000);
            }
        }
    }
}

// Memulai bot
startBot();

// Auto restart saat file diubah
const currentFile = require.resolve(__filename);
fs.watchFile(currentFile, () => {
    fs.unwatchFile(currentFile);
    console.log(chalk.green('\n🔄 ' + __filename + ' updated! Restarting...'));
    delete require.cache[currentFile];
    require(currentFile);
});