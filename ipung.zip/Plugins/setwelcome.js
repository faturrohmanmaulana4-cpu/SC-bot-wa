const fs = require('fs');
const path = require('path');

// Path untuk database welcome
const DB_PATH = path.join(__dirname, '../db-welcome.json');

// Fungsi untuk memuat database
function loadDB() {
    if (!fs.existsSync(DB_PATH)) {
        const defaultDB = {};
        fs.writeFileSync(DB_PATH, JSON.stringify(defaultDB, null, 2));
        return defaultDB;
    }
    return JSON.parse(fs.readFileSync(DB_PATH, 'utf-8'));
}

// Fungsi untuk menyimpan database
function saveDB(data) {
    fs.writeFileSync(DB_PATH, JSON.stringify(data, null, 2));
}

const handler = async (m, { sock, text, command, isGroup, isOwner, groupMetadata, reply }) => {
    if (!isGroup) return reply('❌ *Command ini hanya bisa digunakan di grup!*');
    
    try {
        const db = loadDB();
        const groupId = m.chat;
        
        // Dapatkan metadata grup
        let metadata = groupMetadata;
        if (!metadata) {
            try {
                metadata = await sock.groupMetadata(groupId);
            } catch (error) {
                console.error('Error fetching group metadata:', error);
                return reply('❌ *Gagal mengambil data grup. Pastikan bot adalah admin!*');
            }
        }
        
        const groupName = metadata?.subject || 'Grup Ini';
        
        // Inisialisasi settings grup jika belum ada
        if (!db[groupId]) {
            db[groupId] = {
                welcome: {
                    enabled: true, // DEFAULTNYA AKTIF
                    text: '🎉 Selamat datang @user di @group!\n\nSemoga betah ya! 😊',
                    image: 'https://raw.githubusercontent.com/zionjs/whatsapp-media/main/file_1761997287781'
                },
                goodbye: {
                    enabled: true, // DEFAULTNYA AKTIF
                    text: '👋 Selamat tinggal @user!\n\nSemoga sukses selalu! 💫',
                    image: 'https://raw.githubusercontent.com/zionjs/whatsapp-media/main/file_1761997163995'
                }
            };
            saveDB(db);
        }
        
        switch (command) {
            case 'welcome':
                const action = text?.toLowerCase();
                
                if (!action || !['on', 'off', 'status'].includes(action)) {
                    const status = db[groupId].welcome.enabled ? '✅ AKTIF' : '❌ NONAKTIF';
                    return reply(`📋 *STATUS WELCOME*\n\nStatus: ${status}\n\nGunakan:\n• *.welcome on* - Aktifkan welcome\n• *.welcome off* - Nonaktifkan welcome\n• *.welcome status* - Lihat status detail`);
                }
                
                if (action === 'status') {
                    const status = db[groupId].welcome.enabled ? '✅ AKTIF' : '❌ NONAKTIF';
                    const settings = db[groupId].welcome;
                    
                    const preview = settings.text
                        .replace(/@user/g, 'Anda')
                        .replace(/@group/g, groupName)
                        .replace(/@desc/g, metadata.desc || 'Tidak ada deskripsi')
                        .replace(/@member/g, metadata.participants?.length || 0)
                        .replace(/@admin/g, 'Admin');
                    
                    await reply(`📋 *PENGATURAN WELCOME*\n\n┌─「 📊 Status 」\n│ ${status}\n└─\n\n┌─「 📝 Teks 」\n│ ${preview}\n└─\n\n┌─「 🖼️ Gambar 」\n│ ${settings.image}\n└─`);
                    return;
                }
                
                const newStatus = action === 'on';
                db[groupId].welcome.enabled = newStatus;
                saveDB(db);
                
                await reply(`✅ *Welcome berhasil ${newStatus ? 'diaktifkan' : 'dinonaktifkan'}!*`);
                break;
                
            case 'goodbye':
                const goodbyeAction = text?.toLowerCase();
                
                if (!goodbyeAction || !['on', 'off', 'status'].includes(goodbyeAction)) {
                    const status = db[groupId].goodbye.enabled ? '✅ AKTIF' : '❌ NONAKTIF';
                    
                    return reply(`📋 *STATUS GOODBYE*\n\nStatus: ${status}\n\nGunakan:\n• *.goodbye on* - Aktifkan goodbye\n• *.goodbye off* - Nonaktifkan goodbye\n• *.goodbye status* - Lihat status detail`);
                }
                
                if (goodbyeAction === 'status') {
                    const status = db[groupId].goodbye.enabled ? '🟢 AKTIF' : '🔴 NONAKTIF';
                    const settings = db[groupId].goodbye;
                    
                    const preview = settings.text
                        .replace(/@user/g, 'Anda')
                        .replace(/@group/g, groupName)
                        .replace(/@desc/g, metadata.desc || 'Tidak ada deskripsi')
                        .replace(/@member/g, metadata.participants?.length || 0)
                        .replace(/@admin/g, 'Admin');
                    
                    await reply(`📋 *PENGATURAN GOODBYE*\n\n┌─「 📊 Status 」\n│ ${status}\n└─\n\n┌─「 📝 Teks 」\n│ ${preview}\n└─\n\n┌─「 🖼️ Gambar 」\n│ ${settings.image}\n└─`);
                    return;
                }
                
                const goodbyeNewStatus = goodbyeAction === 'on';
                db[groupId].goodbye.enabled = goodbyeNewStatus;
                saveDB(db);
                
                await reply(`✅ *Goodbye berhasil ${goodbyeNewStatus ? 'diaktifkan' : 'dinonaktifkan'}!*`);
                break;
                
            case 'setwelcome':
                if (!text) return reply('❌ *Format salah!*\n\nContoh: *.setwelcome Selamat datang @user di @group!*');
                
                db[groupId].welcome.text = text;
                saveDB(db);
                
                const welcomePreview = text
                    .replace(/@user/g, 'Anda')
                    .replace(/@group/g, groupName)
                    .replace(/@desc/g, metadata.desc || 'Tidak ada deskripsi')
                    .replace(/@member/g, metadata.participants?.length || 0)
                    .replace(/@admin/g, 'Admin');
                
                await reply(`✅ *Teks welcome berhasil diatur!*\n\n📝 Preview:\n${welcomePreview}`);
                break;
                
            case 'setgoodbye':
                if (!text) return reply('❌ *Format salah!*\n\nContoh: *.setgoodbye Selamat tinggal @user!*');
                
                db[groupId].goodbye.text = text;
                saveDB(db);
                
                const goodbyePreview = text
                    .replace(/@user/g, 'Anda')
                    .replace(/@group/g, groupName)
                    .replace(/@desc/g, metadata.desc || 'Tidak ada deskripsi')
                    .replace(/@member/g, metadata.participants?.length || 0)
                    .replace(/@admin/g, 'Admin');
                
                await reply(`✅ *Teks goodbye berhasil diatur!*\n\n📝 Preview:\n${goodbyePreview}`);
                break;
                
            case 'setwelcomeimage':
                if (!text) return reply('❌ *Format salah!*\n\nContoh: *.setwelcomeimage https://example.com/image.jpg*');
                
                if (!text.startsWith('http')) {
                    return reply('❌ *Format URL salah! Pastikan dimulai dengan http/https*');
                }
                
                db[groupId].welcome.image = text;
                saveDB(db);
                
                await reply('✅ *Gambar welcome berhasil diatur!*');
                break;
                
            case 'setgoodbyeimage':
                if (!text) return reply('❌ *Format salah!*\n\nContoh: *.setgoodbyeimage https://example.com/image.jpg*');
                
                if (!text.startsWith('http')) {
                    return reply('❌ *Format URL salah! Pastikan dimulai dengan http/https*');
                }
                
                db[groupId].goodbye.image = text;
                saveDB(db);
                
                await reply('✅ *Gambar goodbye berhasil diatur!*');
                break;
                
            case 'welcomestatus':
                const welcomeStatus = db[groupId].welcome.enabled ? '✅ AKTIF' : '❌ NONAKTIF';
                const goodbyeStatus = db[groupId].goodbye.enabled ? '✅ AKTIF' : '❌ NONAKTIF';
                
                await reply(`📊 *STATUS WELCOME & GOODBYE*\n\n┌─「 🎉 WELCOME 」\n│ ${welcomeStatus}\n└─\n\n┌─「 👋 GOODBYE 」\n│ ${goodbyeStatus}\n└─\n\n*Command yang tersedia:*\n• .welcome on/off\n• .goodbye on/off\n• .setwelcome <teks>\n• .setgoodbye <teks>\n• .setwelcomeimage <url>\n• .setgoodbyeimage <url>`);
                break;
                
            default:
                break;
        }
    } catch (error) {
        console.error('Error in welcome toggle handler:', error);
        await reply('❌ *Terjadi error saat memproses command!*');
    }
};

handler.help = [
    'welcome <on/off/status> - Aktifkan/nonaktifkan welcome',
    'goodbye <on/off/status> - Aktifkan/nonaktifkan goodbye',
    'setwelcome <teks> - Atur teks welcome',
    'setgoodbye <teks> - Atur teks goodbye', 
    'setwelcomeimage <url> - Atur gambar welcome',
    'setgoodbyeimage <url> - Atur gambar goodbye',
    'welcomestatus - Lihat status welcome & goodbye'
];

handler.tags = ['group'];
handler.command = [
    'welcome',
    'goodbye',
    'setwelcome', 
    'setgoodbye',
    'setwelcomeimage',
    'setgoodbyeimage',
    'welcomestatus'
];

handler.group = true;
handler.admin = true;
handler.botAdmin = true;

module.exports = handler;