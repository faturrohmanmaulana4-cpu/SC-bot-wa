━━━━━━━━━━━━━━━━━━━━━━━━━━━━
       🏮 HU TAO - MD : OFFICIAL SOFTWARE LICENSE 🏮
━━━━━━━━━━━━━━━━━━━━━━━━━━━━

[ 🛠️ ] PROJECT INFORMATION
────────────────────────
• Nama        : HuTao - MD (Multi-Device)
• Developer    : DinzID
• Base Engine  : Fallzx Base
• Build Date   : 2025 - 2026
────────────────────────

[ 📜 ] PERKEMBANGAN
Proyek ini dibangun menggunakan Base asli milik Fallzx.
Melalui tangan DinzID, bot ini mengalami perombakan total 
pada sistem Database, Logic MMORPG, Sistem Clan/Guild, 
serta penambahan fitur Canvas dan Fun Games yang lebih
kompleks. HuTao-MD adalah wujud penyempurnaan dari base
tersebut untuk pengalaman pengguna yang lebih seru.

[ ⚖️ ] PASAL PENGGUNAAN (TOS)
Dengan menggunakan script ini, Anda setuju untuk:

1. CREDIT TETAP ABADI
   Dilarang keras menghapus nama DinzID (Developer) dan 
   Fallzx (Base Provider) dari command About, Credit, 
   atau Header Script. Hargai jempol kami yang keriting.

2. PENGGUNAAN NON-KOMERSIAL
   Script ini dibagikan untuk penggunaan pribadi/komunitas.
   Dilarang menjual kembali (Resell).

3. RECODE & MODIFIKASI
   Silahkan kembangin lagi, tambah fitur sesuka hati,
   tapi jangan ngaku-ngaku ini buatan lu dari nol. 
   Keep it real, wir!

4. TANGGUNG JAWAB
   Developer tidak bertanggung jawab atas penyalahgunaan
   bot (seperti spam, konten ilegal, atau banned nomor).
   Gunakan dengan bijak dan dewasa.

[ 🚫 ] PELANGGARAN KERAS
───────────────────────────
• Menghapus watermark di file core (msg.js, listmenu.js).
• Mengklaim fitur RPG/Clan ciptaan sendiri padahal cuma copas.
• Menjual fitur yang seharusnya gratis di komunitas.
• Menjual Script HuTao MD 
• Hapus Credit & Claim Sc 
───────────────────────────


[❗] INFORMATION
───────────────────────────
> Script ini menggunakan security, dan tidak bisa mengubah variable DinzBotz Dll. Kalau kamu ingin mengrename dan reupload silahkan hubungi owner untuk mendapatkan izin!. setelah mendapatkan izin owner akan memasukan nomor kamu kedalam database. 

───────────────────────────


[ 🏮 ] QUOTES OF THE DAY
"Hargai karya orang lain jika ingin karyamu dihargai.
Coding itu seni, jangan cuma jadi tukang ganti nama.
( Saya Termasuk sih )😹"

[ 📞 ] CONTACT DEVELOPER
• WhatsApp  : wa.me/6283159227378
• Youtube    : youtube.com/DinzID
• Instagram  : Instagram.com/dinzid04

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    © 2026 DinzID | HuTao-MD Team | All Rights Reserved.
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    𝙅𝘼𝙉𝙂𝘼𝙉 𝙃𝘼𝙋𝙐𝙎 𝘾𝙍𝙀𝘿𝙄𝙏 𝙃𝘼𝙍𝙂𝘼𝙄 𝙋𝙀𝙉𝙂𝙀𝙈𝘽𝘼𝙉𝙂 !
       ᴅɪʟᴀʀᴀɴɢ ʜᴀᴘᴜs ғɪʟᴇ ɪɴɪ ᴋᴀʟᴏ ɢᴀ ᴍᴀᴜ ᴇʀʀᴏʀ!
